Foolscreen-Theme

Ce theme est le compl�ment du Mix FoolScreen pour Universal XML Scraper(https://github.com/Universal-Rom-Tools/Universal-XML-Scraper).
Cet outil va g�n�rer le background pour chaque fiche de jeu.

Theme inspir� par les themes recalbox et simple dont il reprend certains �l�ments.
A utiliser avec EmulationStation(http://www.emulationstation.org/)

Source background: http://wlinfo.net/wp-content/uploads/2016/03/gaming-background.jpg

Syst�mes support�s:
- GameBoy
- GameBoy Advance
- MegaDrive
- Nintendo Entertainment System
- Super Nintendo
- Autre � venir